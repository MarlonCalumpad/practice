#include <iostream>
#include <stdlib.h>
#include <windows.h>

using namespace std;

int main()
{
    int num=100, choice, count;
    string item[num], neu, del, ins;

    cout << "\n\n\n\n\n\t\t\t               __" << endl;
    cout << "\t\t\t_____________ /" << endl;
    cout << "\t\t\t _/___/___/_ /" << endl;
    cout << "\t\t\t  _/___/___ /" << endl;
    cout << "\t\t\t  __/____/_/" << endl;
    cout << "\t\t\t   O     O" << endl;
    cout << "\n\t\t\tMy Shopping LIst" << endl;
    cout << "\n\n\n\n\n\n\n\t\t\t\t\t   ";
    system("pause");
    system("cls");
    cout << "\n\n\n\n\n\n\t\t\t\tLoading . . ." << endl;
    Sleep(850);
    system("cls");
    cout << "\n\n\tCreate, edit and organize your shopping list in the simplest way ever!" << endl;
    cout << "\n\n\n Enter the number of item that you want to list : ";
    cin >> num;
    cout << "\n\n\n\tEnter the Item\n" << endl;
    for (int i=0; i<num; i++)
    {
        cin >> item[i];
    }
    cout << "\n";
    system("pause");
    system("cls");
    cout << "\n\n\n\n\n\n\t\t\t\tLoading . . ." << endl;
    Sleep(850);
    system("cls");
    cout << "\nYour Shopping List :\n" << endl;
    for (int i=0; i<num; i++)
    {
        cout << "\t" << i+1 << ". " << item[i] << endl;
    }
    here:
    cout << "\n\n\t\t\t";
    system("pause");
    system("cls");
    cout << "\n\n\n\n\n\n\t\t\t\tLoading . . ." << endl;
    Sleep(850);
    system("cls");
    cout << "\nWhat do you want to do?\n" << endl;
    cout << "\t[1] Insert another item\n\t[2] Delete item\n\t[3] Display your shopping list\n\t[4] Exit" << endl;
    cout << "\n\t\t     Enter your choice ";
    cin >> choice;

    switch (choice)
    {
    case 1:
        system("cls");
        cout << "\nYour Shopping List :\n" << endl;
        for (int i=0; i<num; i++)
        {
            cout << "\t" << i+1 << ". " << item[i] << endl;
        }
        cout << "\n\t\tEnter the item you want to insert ";
        cin >> ins;
        item[num]=ins;
        cout << "\n\t\t\t\tItem " << ins << " was inserted" << endl;
        cout << "\n\n\t\t\t\t";
        system("pause");
        system("cls");
        cout << "\n\n\n\n\n\n\t\t\t\tLoading . . ." << endl;
        Sleep(850);
        system("cls");
        cout << "\nNow the new shopping list is :\n" << endl;
        for (int i=0; i<num+1; i++)
        {
            cout << "\t" << i+1 << ". " << item[i] << endl;
        }
        break;
    case 2:
        system("cls");
        cout << "\nYour Shopping List :\n" << endl;
        for (int i=0; i<num+1; i++)
        {
            cout << "\t" << i+1 << ". " << item[i] << endl;
        }
        cout << "\n\t\tEnter the item you want to delete ";
        cin >> del;
        for (int i=0; i<num; i++)
        {
            if (item[i]==del)
            {
                for (int b=i; b<num; b++)
                {
                    item[b]= item[b+1];
                }
                count++;
                break;
            }
        }
        item[num]=del;
        num--;
        count--;
        cout << "\n\t\t\t\tItem " << del << " was deleted" << endl;
        cout << "\n\n\t\t\t\t";
        system("pause");
        system("cls");
        cout << "\n\n\n\n\n\n\t\t\t\tLoading . . ." << endl;
        Sleep(850);
        system("cls");
        cout << "\nNow the new shopping list is :\n" << endl;
        for (int i=0; i<num+1; i++)
        {
            cout << "\t" << i+1 << ". " << item[i] << endl;
        }
        break;
    case 3:
        system("cls");
        cout << "\nYour Shopping List :\n" << endl;
        for (int i=0; i<num+1; i++)
        {
            cout << "\t" << i+1 << ". " << item[i] << endl;
        }
        break;
    case 4:
        return 0;
        break;
    default:
        cout << "\n\n\t\t\t\tInvalid choice" << endl;
        cout << "\n\n\t\t\t\t";
        system("pause");
        system("cls");
        cout << "\n\n\n\n\n\n\t\t\t\tLoading . . ." << endl;
        Sleep(850);
        system("cls");
        break;
    }
    goto here;
    return 0;
}
